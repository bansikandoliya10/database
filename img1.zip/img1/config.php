<?php
$con=mysqli_connect ("localhost","root","","carbook");
if($con==true)
{
    echo "yes";
}
else
{
    echo "no";
}

?>