<?php 
include "config.php";
    $id=$_REQUEST['id'];
    $filename = $_FILES["uploadfile"]["name"];
    $tempname = $_FILES["uploadfile"]["tmp_name"];
    $folder = "image/" . $filename;
    $carname=$_REQUEST ['carname'];
    $carprice=$_REQUEST ['carprice'];
    move_uploaded_file($tempname,$folder);
    $update=" UPDATE `image` SET `uploadfile`='$filename',`carname`='$carname',`carprice`='$carprice' WHERE `id`='$id'";
    $result=mysqli_query($con,$update);
    header("location:detail.php");

?>