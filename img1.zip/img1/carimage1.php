<?php
	$con = mysqli_connect("localhost","root","","carbook");
?>

<!DOCTYPE html>
<html>

<head>
	<title>Image Upload</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css" />
    <style>*{
	margin: 0; 
	padding: 0; 
	box-sizing: border-box;
}

#content{
	width: 50%;
	justify-content: center;
	align-items: center;
	margin: 20px auto;
	border: 1px solid #cbcbcb;
}
form{
	width: 50%;
	margin: 20px auto;
}

#display-image{
	width: 100%;
	justify-content: center;
	padding: 5px;
	margin: 15px;
}
img{
	margin: 5px;
	width: 350px;
	height: 250px;
}
</style>
</head>

<body>
	<div id="content">
		<form method="POST" action="insert.php" enctype="multipart/form-data">
			<div class="form-group">
				<input class="form-control" type="file" name="uploadfile" value="" />
			</div>
            <div class="form-group">
				<input class="form-control" type="text" name="carname" value="" placeholder="car name"/>
			</div>
            <div class="form-group">
				<input class="form-control" type="text" name="carprice" value="" placeholder="car price" />
			</div>
			<div class="form-group">
				<button class="btn btn-primary" type="submit" name="upload">UPLOAD</button>
			</div>
		</form>
	</div>
	
</body>																																																												

</html>