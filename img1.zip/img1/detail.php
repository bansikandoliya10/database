<?php 
include "config.php";
$sql="SELECT * FROM `image`";
$result=mysqli_query($con,$sql);
?>
<html>
    <body>
        <table align="center" border="1px ,solid " style="width:50%">
            <tr>
                <th>id</th>
                <th>uploadfile</th>
                <th>carname</th>
                <th>carprice</th>
                <th>update</th>
                <th>delete</th>
            </tr>
            <?php
                while($data=mysqli_fetch_assoc($result))
                {
            ?>
            <tr>
                <td><?php echo $data['id']; ?></td>
                <td><?php echo $data['uploadfile']; ?></td>
                <td><?php echo $data['carname']; ?></td>
                <td><?php echo $data['carprice']; ?></td>
                <td><a href="update.php?id=<?php echo $data['id']; ?>">update</a></td>
                <td><a href="delete.php?id=<?php echo $data['id']; ?>">delete</a></td>
            </tr>
            <?php
                }
            ?>
        </table>
    </body>
</html>