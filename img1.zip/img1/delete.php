<?php
require "config.php";
$id=$_REQUEST['id'];
$delete="DELETE FROM `image` WHERE `id`='$id'";
$result=mysqli_query($con,$delete);
if($result)
{
    header("location:detail.php");
}
  
?>