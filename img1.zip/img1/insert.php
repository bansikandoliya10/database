<?php
    include "config.php";
    $filename = $_FILES["uploadfile"]["name"];
    $tempname = $_FILES["uploadfile"]["tmp_name"];
    $folder = "./image/" . $filename;
    $carname=$_REQUEST ['carname'];
    $carprice=$_REQUEST ['carprice'];
    if (move_uploaded_file($tempname, $folder)) 
    {
        echo "<h3>  Image uploaded successfully!</h3>";
    } 
    else
    {
        echo "<h3>  Failed to upload image!</h3>";
    }
    $insert="insert into `image`(`uploadfile`,`carname`,`carprice`) values('$filename','$carname','$carprice')";
    $result= mysqli_query ($con,$insert);
    if($result==TRUE)
    {
        header("location:carimage1.php");
     }
     else
     {
         echo "Not";
     }

?>